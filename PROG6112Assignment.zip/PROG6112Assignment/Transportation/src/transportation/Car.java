
package transportation;


public class Car extends Transportation {
    
    private String brand;
    private int doors;

    public Car(String brand, int capacity, int doors) {
        super("Car", capacity);  // Calling the constructor of the base class (Transportation)
        this.brand = brand;
        this.doors = doors;
    }

    @Override
    public void move() {
        System.out.println("The car is driving on the road.");
    }

    public String getBrand() {
        return brand;
    }

    public int getDoors() {
        return doors;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();  // Calling the displayInfo method of the base class
        System.out.println("Brand: " + brand);
        System.out.println("Doors: " + doors);
    }
}



