
package transportation;


public class Transportation {
    
   
    private String type;
    private int capacity;

    public Transportation(String type, int capacity) {
        this.type = type;
        this.capacity = capacity;
    }

    public void move() {
        System.out.println("This transportation is moving.");
    }

    public String getType() {
        return type;
    }

    public int getCapacity() {
        return capacity;
    }

    public void displayInfo() {
        System.out.println("Type: " + type);
        System.out.println("Capacity: " + capacity + " people");
    }
    }



