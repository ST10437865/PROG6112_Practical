
package transportation;


public class Bicycle extends Transportation {
   
    
    private boolean hasGears;

    public Bicycle(int capacity, boolean hasGears) {
        super("Bicycle", capacity);  // Calling the constructor of the base class (Transportation)
        this.hasGears = hasGears;
    }

    @Override
    public void move() {
        System.out.println("The bicycle is being pedaled.");
    }

    public boolean hasGears() {
        return hasGears;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();  // Calling the displayInfo method of the base class
        System.out.println("Has Gears: " + hasGears);
    }
}



