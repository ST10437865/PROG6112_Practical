
package transportation;


public class Main {

        public static void main(String[] args) {
        
        // Creating a Car object
        Car car = new Car("Toyota", 5, 4);
        System.out.println("Car Information:");
        car.displayInfo();
        car.move();
        System.out.println();

        // Creating a Bicycle object
        Bicycle bike = new Bicycle(1, true);
        System.out.println("Bicycle Information:");
        bike.displayInfo();
        bike.move();
        System.out.println();
    }
}

    


            
    
    



