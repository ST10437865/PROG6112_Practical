/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package transportation;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class TransportationTest {
    
 

    private Transportation transportation;

    @Before
    public void setUp() {
        // Create an instance of Transportation before each test
        transportation = new Transportation("Bus", 50);
    }

    @Test
    public void testGetType() {
        // Test the getType method
        assertEquals("Bus", transportation.getType());
    }

    @Test
    public void testGetCapacity() {
        // Test the getCapacity method
        assertEquals(50, transportation.getCapacity());
    }

    @Test
    public void testMove() {
        transportation.move(); 
        //Output "This transportation is moving."
    }

    @Test
    public void testDisplayInfo() {
        
        transportation.displayInfo();
        // Expected output: Type Bus Capacity 50 people
    }
}

