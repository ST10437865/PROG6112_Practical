/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package transportation;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class BicycleTest {
    

    private Bicycle bicycle;

    @Before
    public void setUp() {
        // Instance of Bicycle before each test
        bicycle = new Bicycle(1, true);  // capacity = 1, hasGears = true
    }

    @Test
    public void testHasGears() {
        // hasGears method
        assertTrue(bicycle.hasGears());
    }

    @Test
    public void testGetCapacity() {
        //inherited getCapacity method
        assertEquals(1, bicycle.getCapacity());
    }

    @Test
    public void testMove() {
        // Overridden 
        bicycle.move();  // Expected output: "The bicycle is being pedaled."
    }

    @Test
    public void testDisplayInfo() {
        // Overridden 
        bicycle.displayInfo();
        // Expected output: Type Bicycle, Capacity 1 person, HAs gears True
        
    }
}
