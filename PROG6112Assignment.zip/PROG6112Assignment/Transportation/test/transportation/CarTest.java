/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package transportation;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class CarTest {
    
 
    private Car car;

    @Before
    public void setUp() {
        // Instance of Car before each test
        car = new Car("Toyota", 5, 4);  // brand = Toyota, capacity = 5, doors = 4
    }

    @Test
    public void testGetBrand() {
        // GetBrand method
        assertEquals("Toyota", car.getBrand());
    }

    @Test
    public void testGetDoors() {
        // GetDoors method
        assertEquals(4, car.getDoors());
    }

    @Test
    public void testGetCapacity() {
        
        assertEquals(5, car.getCapacity());
    }

    @Test
    public void testMove() {
        // Overridden 
        car.move();  
        // Output "The car is driving on the road."
    }

    @Test
    public void testDisplayInfo() {
        // Overridden 
        car.displayInfo();
        // Expected output: Type Car, Capacity 5 people, Brand Toyota, Doors 4
        
    }
}

