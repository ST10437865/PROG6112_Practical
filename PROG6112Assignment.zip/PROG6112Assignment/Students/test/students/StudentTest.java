package students;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class StudentTest {

    private Student student1;
    private Student student2;

    @Before
    public void setUp() {
        student1 = new Student("10111", "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        student2 = new Student("10112", "A.Smith", 21, "asmith@ymail.com", "disd");
        Student.saveStudent(student1);
        Student.saveStudent(student2);
    }

    @Test
    public void testSaveStudent() {
        // Check that the students list contains the saved students
        assertNotNull(Student.searchStudent("10111"));
        assertNotNull(Student.searchStudent("10112"));
    }

    @Test
    public void testSearchStudent_Found() {
        Student result = Student.searchStudent("10111");
        assertEquals(student1, result);
    }

    @Test
    public void testSearchStudent_NotFound() {
        Student result = Student.searchStudent("99999");
        assertNull(result);
    }

    @Test
    public void testDeleteStudent_Success() {
        boolean deleted = Student.deleteStudent("10111");
        assertTrue(deleted);
        assertNull(Student.searchStudent("10111"));
    }

    @Test
    public void testDeleteStudent_NotFound() {
        boolean deleted = Student.deleteStudent("99999");
        assertFalse(deleted);
    }

    @Test
    public void testStudentReport() {
       
        Student.printStudentReport();
        assertNotNull(Student.searchStudent("10111"));
        assertNotNull(Student.searchStudent("10112"));
    }
}
