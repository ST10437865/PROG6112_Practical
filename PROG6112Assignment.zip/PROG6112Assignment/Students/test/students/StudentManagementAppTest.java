/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package students;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class StudentManagementAppTest {
    
   

    private Student student1;
    private Student student2;

    @Before
    public void setUp() {
        // Set up two sample students for testing
        student1 = new Student("101", "John Doe", 18, "john@example.com", "Math");
        student2 = new Student("102", "Jane Smith", 20, "jane@example.com", "Science");

        // Save the students to the list
        Student.saveStudent(student1);
        Student.saveStudent(student2);
    }

    @Test
    public void testSaveStudent() {
       
        assertNotNull(Student.searchStudent("101"));
        assertNotNull(Student.searchStudent("102"));
    }

    @Test
    public void testSearchStudent_Found() {
        // Teststudent was found
        Student foundStudent = Student.searchStudent("101");
        assertEquals("John Doe", foundStudent);
    }

    @Test
    public void testSearchStudent_NotFound() {
       
        assertNull(Student.searchStudent("999"));
    }

    @Test
    public void testDeleteStudent_Success() {
        // Test that a student was deleted successfully
        boolean deleted = Student.deleteStudent("101");
        assertTrue(deleted);
        assertNull(Student.searchStudent("101"));
    }

    @Test
    public void testDeleteStudent_NotFound() {
        // Test deleting a student that is not found
        boolean deleted = Student.deleteStudent("999");
        assertFalse(deleted);
    }

    @Test
    public void testPrintStudentReport() {
        // Check that students are printed in the report
        Student.printStudentReport();
       
    }
}