package students;

import java.util.ArrayList;

public class Student {

    static Object getStudents() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;
    private static ArrayList<Student> students = new ArrayList<>();

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public String getId() {
        return id;
    }

    public static void saveStudent(Student student) {
        students.add(student);
        System.out.println("Student details have been successfully saved!");
    }

    public static Student searchStudent(String id) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return student;
            }
        }
        return null;
    }

    public static boolean deleteStudent(String id) {
        Student student = searchStudent(id);
        if (student != null) {
            students.remove(student);
            return true;
        }
        return false;
    }

    public static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
        } else {
            for (int i = 0; i < students.size(); i++) {
                Student student = students.get(i);
                System.out.println("STUDENT " + (i + 1));
                System.out.println(student);
                System.out.println("------------------------");
            }
        }
    }

    public static void exitStudentApplication() {
        System.out.println("Exiting application. Goodbye!");
        System.exit(0);
    }

    @Override
    public String toString() {
        return "STUDENT ID: " + id + "\n" +
               "STUDENT NAME: " + name + "\n" +
               "STUDENT AGE: " + age + "\n" +
               "STUDENT EMAIL: " + email + "\n" +
               "STUDENT COURSE: " + course;
    }

   
   
}



