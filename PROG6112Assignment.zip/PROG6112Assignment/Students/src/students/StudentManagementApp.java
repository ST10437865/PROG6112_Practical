package students;

import java.util.Scanner;

public class StudentManagementApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;

        while (true) {
            displayMainMenu();
            input = scanner.nextLine();

            if (input.equalsIgnoreCase("M")) {
                displayMenuOptions(scanner);
            } else {
                Student.exitStudentApplication();
            }
        }
    }

    private static void displayMainMenu() {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("**********************************");
        System.out.println("Please enter (M) to launch menu or any key to exit");
    }

    private static void displayMenuOptions(Scanner scanner) {
        while (true) {
            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> captureNewStudent(scanner);
                case "2" -> searchForStudent(scanner);
                case "3" -> deleteStudent(scanner);
                case "4" -> printStudentReport(scanner);
                case "5" -> {
                    Student.exitStudentApplication();
                    return;
                }
                default -> System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void captureNewStudent(Scanner scanner) {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("************************");
        System.out.print("Please enter the student id: ");
        String id = scanner.nextLine();

        System.out.print("Please enter the student name: ");
        String name = scanner.nextLine();

        int age;
        while (true) {
            System.out.print("Please enter the student age: ");
            String ageInput = scanner.nextLine();
            try {
                age = Integer.parseInt(ageInput);
                if (age >= 16) {
                    break;
                } else {
                    System.out.println("You've entered an invalid student age!");
                    System.out.println("Please re-enter the student age >>");
                }
            } catch (NumberFormatException e) {
                System.out.println("You've entered an invalid student age!!!");
                System.out.println("Please re-enter the student age >>");
            }
        }

        System.out.print("Please enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Please enter the student course: ");
        String course = scanner.nextLine();

        Student newStudent = new Student(id, name, age, email, course);
        Student.saveStudent(newStudent);

        System.out.println("Enter (M) to launch menu or any other key to exit");
        String input = scanner.nextLine();
        if (!input.equals("M")) {
            Student.exitStudentApplication();
        }
    }

    private static void searchForStudent(Scanner scanner) {
        System.out.print("Enter the student id to search: ");
        String id = scanner.nextLine();
        Student foundStudent = Student.searchStudent(id);

        if (foundStudent != null) {
            System.out.println(foundStudent);
        } else {
            System.out.println("Student with Student ID: " + id + " was not found!");
        }

        System.out.println("Enter (M) to launch menu or any other key to exit");
        String input = scanner.nextLine();
        if (!input.equals("M")) {
            Student.exitStudentApplication();
        }
    }

    private static void deleteStudent(Scanner scanner) {
        System.out.print("Enter the student id to delete: ");
        String id = scanner.nextLine();

        System.out.print("Are you sure you want to delete student " + id + " from the system? Yes (Y) to delete: ");
        String confirmation = scanner.nextLine();
        if (confirmation.equalsIgnoreCase("Y")) {
            if (Student.deleteStudent(id)) {
                System.out.println("Student with Student ID: " + id + " was deleted!");
            } else {
                System.out.println("Student with Student ID: " + id + " was not found!");
            }
        } else {
            System.out.println("Delete completed.");
        }

        System.out.println("Enter (M) to launch menu or any other key to exit");
        String input = scanner.nextLine();
        if (!input.equals("M")) {
            Student.exitStudentApplication();
        }
    }

    private static void printStudentReport(Scanner scanner) {
        System.out.println("Print student report selected.");
        Student.printStudentReport();

        System.out.println("Enter (M) to launch menu or any other key to exit");
        String input = scanner.nextLine();
        if (!input.equals("M")) {
            Student.exitStudentApplication();
        }
    }
}